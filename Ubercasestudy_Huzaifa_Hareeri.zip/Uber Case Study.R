#Get the data into R
getwd()

uber <- read.csv("Uber Request Data.csv", stringsAsFactors = FALSE)

#checking the data
head(uber)
str(uber)

library(plyr)
library(dplyr)
library(ggplot2)
library(lubridate)
library(readxl)
library(writexl)

#getting dates in a standard format. Replacing "/" with "-"
std_datetime <- as.Date(uber$Request.timestamp, format = "%d-%m-%Y %H:%M:%S")
View(std_datetime)

uber$std_datetime <- gsub("/","-",uber$Request.timestamp)

library(lubridate)
uber$std_datetime <- parse_date_time(uber$std_datetime, "dmY HMS", truncated = 3)


View(uber)

#add a column with dates only
uber$req_date <- as.Date(uber$std_datetime, format = "%d-%m-%Y")
View(uber)

#add a column with Request Time
req_datetime <- as.POSIXlt(uber$std_datetime, format = "%d-%m-%Y %H:%M:%S")

#Extract request hours, minutes and weekday
uber$req_hr <- format(uber$std_datetime, "%H")
uber$req_min <- format(uber$std_datetime, "%M")
uber$req_day <- weekdays(uber$std_datetime)


View(uber)
#Standardising Drop Date and time

uber$drp_datetime <- parse_date_time(uber$Drop.timestamp, "dmY HMS", truncated = 3)
uber$drp_date <- as.Date(uber$drp_datetime, format = "%d-%m-%Y")

#Extract drop hours, minutes and weekday

uber$drp_hr <- format(uber$drp_datetime, "%H")
uber$drp_min <- format(uber$drp_datetime, "%M")
uber$drp_day <- weekdays(uber$drp_datetime)

View(uber)


#Creating time bucket
req_hr1 <- as.numeric(uber$req_hr)
uber$day_bucket <- cut(req_hr1, breaks=c(-1,4,11,16,19,21,23), labels=c("Early Hours", "Morning", "Afternoon", "Peak Evening", "Night","Late Night"))
View(uber)
ggplot(uber, aes(x=uber$day_bucket, fill=uber$Pickup.point)) + geom_bar(stat = "count", position = "dodge") + facet_grid(uber$Status ~ .)

#Calculating trip time in minutes

uber$trip_time <- round(uber$drp_datetime - uber$std_datetime, 0)

#Plotting

#Visualizing demand
ggplot(uber, aes(x=uber$Status, ..count..)) + geom_bar(aes(fill=uber$Pickup.point), position = "dodge")

ggplot(uber, aes(x=uber$Pickup.point, ..count..)) + geom_bar(aes(fill=uber$Status))

# Comparing demand as per the day of the week and time of the day.
barplot(table(uber$req_day))
barplot(table(uber$day_bucket))

#Comparing Demand with cancellation/no cars as per the time bucket of the day
ggplot(uber, aes(x=uber$day_bucket, ..count..)) + geom_bar(aes(fill=uber$Status))

#Comparing Trip completion, availabity and cancellation as per the trip starting point and time bucket
ggplot(uber, aes(x=uber$req_hr, fill=uber$Status)) + geom_bar() + xlab("Request Hour") + labs(title = "Demand Per Hour")
ggplot(uber, aes(x=uber$day_bucket, fill=uber$Pickup.point)) + geom_bar(stat = "count", position = "dodge") + facet_grid(uber$Status ~ .)


# Calculating averge trip time as per point of origin

triptime_per_origin <- ddply(uber, .(uber$Pickup.point), summarize, Average=mean(uber$trip_time, na.rm=TRUE))
View(triptime_per_origin)

# Visualising Trip time based on..
# Per Trip Origin 
ggplot(uber, aes(x=uber$Pickup.point, y=uber$trip_time)) + geom_boxplot()

# Per Time of the day
ggplot(uber, aes(x=uber$day_bucket, y=uber$trip_time)) + geom_boxplot()


#calculating average cancellation and comparing it with cancellation per driver

driver_data <- table(uber$Driver.id, uber$Status)
driver_data1 <- data.frame(driver_data)
View(driver_data1)

driver_canc <- subset(driver_data1, driver_data1$Var2 == "Cancelled")
driver_trip_comp <- subset(driver_data1, driver_data1$Var2 == "Trip Completed")
View(driver_canc)
View(driver_trip_comp)

driver_details <- data.frame(driver_canc$Var1, driver_canc$Freq, driver_trip_comp$Freq,(driver_canc$Freq+driver_trip_comp$Freq))
View(driver_details)
col_names <- c("Driver ID", "Cancellation", "Trips", "Total Requests")
colnames(driver_details) <- col_names

can_rate <- round((driver_details$Cancellation/driver_details$`Total Requests`)*100,2)
View(can_rate)
driver_details$can_rate <- can_rate
View(driver_details)

ggplot(driver_canc, aes(x=driver_canc$Freq)) + geom_histogram(binwidth = 1, col = "black", fill="bisque3") +xlab("Cancellation")

driver_canc_plot <- ggplot(driver_canc, aes(x=as.factor(driver_canc$Var1), y=driver_canc$Freq)) + geom_point() +xlab("Driver ID") +ylab("Cancellation") +theme(axis.text.x = element_text(size = 5, angle = 90))
driver_trip_plot <- ggplot(driver_trip_comp, aes(x=as.factor(driver_trip_comp$Var1), y=driver_trip_comp$Freq)) +geom_point() +xlab("Driver ID") +ylab("Trips") +theme(axis.text.x = element_text(size = 5, angle = 90))
driver_can_rate <- ggplot(driver_details, aes(x=driver_details$`Driver ID`, y=driver_details$can_rate))+geom_point() + xlab("Driver ID") + ylab("Cancellation Rate") + theme(axis.text.x = element_text(size = 5, angle = 90))
driver_canc_plot
driver_trip_plot
driver_can_rate

#Export date into excel for plotting in Tableau
write_xlsx(uber, "uber_case_study.xlsx")
